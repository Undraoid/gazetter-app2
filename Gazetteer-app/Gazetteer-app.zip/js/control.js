// Description: A simple scale control that shows the scale of the current center of screen in metric (m/km) and imperial (mi/ft) systems
// Source: https://leafletjs.com/reference-1.7.1.html#control-scale
// Implementation: Added Scale at the bottom left of the map.
L.control.scale().addTo(map);

// Description: A basic zoom control with two buttons (zoom in and zoom out)
// Source: https://leafletjs.com/reference-1.7.1.html#control-zoom
// Implementation: Setting Zoom control (+, -) on the top right of the map
map.zoomControl.setPosition("topright");

// Description: A Leaflet control that search markers/features location by custom property.
// Source:  https://github.com/stefanocudini/leaflet-search
let controlSearch = new L.Control.Search({
  position: "topleft",
  layer: district_boundary, // name of the layer
  initial: true, // search elements only by initial text
  marker: false, // false for hide
  textPlaceholder: "Search...",
  propertyName: "NAME",
});

// This function will execute, when a country is searched and found on control search bar
controlSearch.on("search:locationfound", function (e) {
  district_boundary.eachLayer(function (layer) {
    if (layer.feature.properties.NAME == e.text) {
      let ISO_A2 = layer.feature.properties.ISO_A2;
      highlight_boundary.clearLayers(); //Clears previously selected country
      highlight_boundary.addData(layer.feature); //Adding newly selected country
      map.fitBounds(layer.getBounds()); //Zooming in to country selected
      highlight_boundary.setStyle(highstyle); //Setting style to selected one
      LoadCountryInfo(NAME); //Calling LoadCountryInfo function from below to get the country's info
    }
  });
});

// Implementation: Added Search control bar for searching countries on the top left of the map
map.addControl(controlSearch);

//Ajax for loading the country info
function LoadCountryInfo(name) {
  var selectedCountry = $('.scrollbar option:selected').text(); 
  $.ajax({
    url: "php/getData.php",
    type: "POST",
    data: "country=" + name,
    success: function (response) {
      var output = $.parseJSON(response);
      // let output = JSON.parse(response);
      var countryData = output.countryData;
      var countryName = countryData.name;
      var capital = countryData.capital;
      var population = countryData.population;
      var flag = countryData.flag;
      var currency = countryData.currencies[0].name;
      var wiki = 'https://en.wikipedia.org/wiki/'+selectedCountry;
      $(".country_name").text(countryName);
      $(".country_capital").text(capital);
      $(".country_population").text(population);
      $(".country_flag").attr('src',flag);
      $(".country_currency").text(currency);
      $(".country_wiki").attr('href',wiki);
      $(".country_wiki").text(selectedCountry);

      var coronaData      =  output.coronaData;
      var totalCases      =  coronaData.cases;
      var active          =  coronaData.active;
      var recovered       =  coronaData.recovered;
      var deaths          =  coronaData.deaths;
      var todayCases      =  coronaData.todayCases;
      var todayRecovered  =  coronaData.todayRecovered;
      var todayDeaths     =  coronaData.todayDeaths;
      var activePerOneMillion =  coronaData.activePerOneMillion;
      var recoveredPerOneMillion = coronaData.recoveredPerOneMillion;
      $('.total_cases').text(totalCases);
      $('.active_cases').text(active);
      $('.rcvrd').text(recovered);
      $('.dths').text(deaths);
      $('.tdcases').text(todayCases);
      $('.tdrc').text(todayRecovered);
      $('.tdths').text(todayDeaths);
      $('.apm').text(activePerOneMillion);
      $('.rpm').text(recoveredPerOneMillion);

      var weatherData      =  output.weather_data;
      var avgTemp          =  weatherData[0];
      var tmpMax           =  weatherData[1];
      var tmpMin           =  weatherData[2];
      var pressure         =  weatherData[3];
      var humidity         =  weatherData[4];
      var cloudPercentage  =  weatherData[5];
      var windSpeed        =  weatherData[6];
      var windDegree       =  coronaData.activePerOneMillion;

      $('.avg_temp').text(avgTemp);
      $('.temp_max').text(tmpMax);
      $('.temp_min').text(tmpMin);
      $('.pressure').text(pressure);
      $('.humidity').text(humidity);
      $('.cloud_percentage').text(cloudPercentage);
      $('.wind_speed').text(windSpeed);
      $('.wind_degree').text(windDegree);
      
      var news_data      =  output.news_data;
      //console.log(news_data);
      var newsHtml = '';
      $(".news_tbl").html('');
      for (var i = 0; i <= 10; i++) {
        data = news_data.data[i].title;
        url = news_data.data[i].url;
        newsHtml = "<tr><td><i class='far fa-newspaper'>"+
        "</i><a href='"+url+"' target='#' class='text-primary'>"+data+"</a></td>"+
        "</tr>";
        $(".news_tbl").append(newsHtml);
      }
     
      $('.center').show();
      $('.loader_main').hide();
    },
  });
}
