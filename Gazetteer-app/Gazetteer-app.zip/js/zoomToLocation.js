function loadCurrent(){
    if (navigator.geolocation) // Check if this is available in older browsers
        navigator.geolocation.getCurrentPosition(function (position) { // Success callback function

            //const latitude = position.coords.latitude;
            const {
                latitude
            } = position.coords; // Destructuring 
            //const longitude = position.coords.longitude;
            const {
                longitude
            } = position.coords; // Destructuring
            // console.log(latitude, longitude); 
            //console.log(`https://www.google.co.uk/maps/@${latitude},${longitude}`);

            // Set latitude and longitude values dynamically by storing in an array variable. 
            const coords = [latitude, longitude];

            locationSelector(latitude,longitude)
            

            // Creating a marker and a popup and add it to the map
            L.marker(coords).addTo(map)
            .bindPopup("<h6 class='text-center'><a href='https://www.google.co.uk/maps/@${latitude},${longitude}' target='_blank'>Your'e Here!</a></h6>")
            .openPopup();

            // Respond to User events

            map.setView(coords, 5);

        },
        function () { // Error callback function
            alert("Could not get your position!");
        })

}

function locationSelector(latitude,longitude){
    var apikey = 'a0cac1c743a343c6a85d6aa791b86ca1';
    var api_url = 'https://api.opencagedata.com/geocode/v1/json'

    var request_url = api_url
    + '?'
    + 'key=' + apikey
    + '&q=' + encodeURIComponent(latitude + ',' + longitude)
    + '&pretty=1'
    + '&no_annotations=1';

    // see full list of required and optional parameters:
    // https://opencagedata.com/api#forward

    var request = new XMLHttpRequest();
    request.open('GET', request_url, true);

    request.onload = function() {
        // see full list of possible response codes:
        // https://opencagedata.com/api#codes

        if (request.status === 200){ 
            // Success!
            var data = JSON.parse(request.responseText);
            data = data.results[0];
            var components = data.components;
            var iso_a2 = components[Object.keys(components)[0]];
            //console.log(iso_a2); // print the location

            $('[name=scrollbar] option').filter(function() { 
            return ($(this).val() == iso_a2); //To select Blue
            }).prop('selected', true);

            LoadCountryInfo(iso_a2);

        } 
        else if (request.status <= 500){ 
          // We reached our target server, but it returned an error
                               
          console.log("unable to geocode! Response code: " + request.status);
          var data = JSON.parse(request.responseText);
          console.log('error msg: ' + data.status.message);
        } else {
          console.log("server error");
        }
    };

    request.onerror = function() {
        // There was a connection error of some sort
        console.log("unable to connect to server");        
    };
    request.send();  // make the request
}

